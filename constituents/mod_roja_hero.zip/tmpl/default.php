<?php defined('_JEXEC') or die; use Joomla\CMS\HTML\HTMLHelper; if (!$list) return; $item=$list[0]; $images=json_decode($item->images ?? '{}'); $src=$images->image_intro ?? $images->image_fulltext ?? ''; ?>
<article class="roja-hero-card">
 <?php if($src): ?><img src="<?php echo htmlspecialchars($src,ENT_QUOTES,'UTF-8'); ?>" alt="<?php echo htmlspecialchars($item->title,ENT_QUOTES,'UTF-8'); ?>" loading="eager" decoding="async"><?php else: ?><div class="roja-placeholder"></div><?php endif; ?>
 <div class="roja-hero-content">
  <?php if($params->get('show_category',1) && !empty($item->category_title)): ?><div class="roja-kicker"><?php echo htmlspecialchars($item->category_title,ENT_QUOTES,'UTF-8'); ?></div><?php endif; ?>
  <h2><a href="<?php echo $item->link; ?>"><?php echo htmlspecialchars($item->title,ENT_QUOTES,'UTF-8'); ?></a></h2>
  <?php if($params->get('show_date',1)): ?><div class="roja-meta"><?php echo HTMLHelper::_('date',$item->publish_up,'d M Y'); ?></div><?php endif; ?>
 </div>
</article>
