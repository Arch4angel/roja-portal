<?php
defined('_JEXEC') or die;

if (!$list) {
    return;
}
?>
<div class="roja-breaking" data-breaker-interval="2500" role="region" aria-live="polite" aria-label="Breaking News">
    <div class="roja-breaking__label">
        <svg class="roja-breaking__icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
            <path d="M12 2.5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 12 2.5zm0 3.2a1.1 1.1 0 0 1 1.1 1.1v4.4a1.1 1.1 0 1 1-2.2 0V6.8A1.1 1.1 0 0 1 12 5.7zm0 10.9a1.35 1.35 0 1 1 0-2.7 1.35 1.35 0 0 1 0 2.7z" fill="currentColor"></path>
        </svg>
        <span>BREAKING</span>
    </div>

    <div class="roja-breaking__viewport">
        <?php $index = 0; foreach ($list as $item): ?>
            <a
                class="roja-breaking__item<?php echo $index === 0 ? ' is-active' : ''; ?>"
                href="<?php echo $item->link; ?>"
                aria-label="<?php echo htmlspecialchars($item->title, ENT_QUOTES, 'UTF-8'); ?>"
                aria-hidden="<?php echo $index === 0 ? 'false' : 'true'; ?>"
                style="<?php echo $index === 0 ? '' : 'display:none;'; ?>"
            >
                <?php echo htmlspecialchars($item->title, ENT_QUOTES, 'UTF-8'); ?>
            </a>
        <?php $index++; endforeach; ?>
    </div>
</div>

<style>
.roja-breaking {
    display: flex;
    align-items: center;
    width: 100%;
    min-height: 56px;
    background: linear-gradient(90deg, #0f172a 0%, #111827 100%);
    border: 1px solid rgba(255,255,255,0.12);
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 14px 30px rgba(15, 23, 42, 0.14);
    font-family: Arial, Helvetica, sans-serif;
    position: relative;
}

.roja-breaking::before {
    content: "";
    position: absolute;
    inset: 0;
    background: linear-gradient(90deg, rgba(255,255,255,0.05), rgba(255,255,255,0), rgba(255,255,255,0.04));
    pointer-events: none;
}

.roja-breaking__label {
    position: relative;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 12px 16px;
    background: linear-gradient(135deg, #ef4444 0%, #b91c1c 100%);
    color: #fff;
    font-size: 0.72rem;
    font-weight: 900;
    letter-spacing: 0.12em;
    text-transform: uppercase;
    white-space: nowrap;
    flex-shrink: 0;
    box-shadow: inset 0 0 0 1px rgba(255,255,255,0.1);
    animation: labelPulse 1.8s ease-in-out infinite alternate;
}

.roja-breaking__label::after {
    content: "";
    position: absolute;
    inset: 0;
    background: rgba(255,255,255,0.08);
    opacity: 0.9;
}

.roja-breaking__label > * {
    position: relative;
    z-index: 1;
}

.roja-breaking__icon {
    width: 16px;
    height: 16px;
    display: block;
    flex-shrink: 0;
}

.roja-breaking__viewport {
    position: relative;
    flex: 1;
    min-width: 0;
    display: flex;
    align-items: center;
    min-height: 56px;
    padding: 0 18px;
    overflow: hidden;
}

.roja-breaking__item {
    position: absolute;
    left: 18px;
    right: 18px;
    top: 50%;
    transform: translateY(18px);
    opacity: 0;
    color: #f8fafc;
    text-decoration: none;
    font-size: 0.95rem;
    font-weight: 700;
    line-height: 1.4;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    letter-spacing: 0.01em;
    transition: opacity 0.42s ease, transform 0.42s ease, filter 0.42s ease;
    filter: blur(3px);
    pointer-events: none;
}

.roja-breaking__item:hover,
.roja-breaking__item:focus {
    color: #ffffff;
    text-decoration: none;
}

.roja-breaking__item.is-active {
    opacity: 1;
    transform: translateY(-50%);
    filter: blur(0);
    pointer-events: auto;
}

@keyframes labelPulse {
    0% {
        box-shadow: inset 0 0 0 1px rgba(255,255,255,0.08), 0 0 0 rgba(239,68,68,0.25);
    }
    100% {
        box-shadow: inset 0 0 0 1px rgba(255,255,255,0.08), 0 0 18px rgba(239,68,68,0.35);
    }
}

@media (max-width: 640px) {
    .roja-breaking {
        flex-direction: column;
        align-items: stretch;
    }

    .roja-breaking__label {
        justify-content: center;
        border-bottom: 1px solid rgba(255,255,255,0.12);
    }

    .roja-breaking__viewport {
        min-height: 48px;
        padding: 10px 12px 12px;
    }

    .roja-breaking__item {
        left: 12px;
        right: 12px;
    }
}
</style>

<script>
(function () {
    var rows = document.querySelectorAll('.roja-breaking');

    rows.forEach(function (row) {
        if (row.dataset.bound === '1') {
            return;
        }

        row.dataset.bound = '1';
        var items = Array.prototype.slice.call(row.querySelectorAll('.roja-breaking__item'));

        if (items.length < 2) {
            return;
        }

        var index = 0;
        var interval = parseInt(row.getAttribute('data-breaker-interval'), 10) || 2500;

        function showItem(nextIndex) {
            index = nextIndex;

            items.forEach(function (item, i) {
                var active = i === index;
                item.classList.toggle('is-active', active);
                item.style.display = active ? 'block' : 'none';
                item.setAttribute('aria-hidden', active ? 'false' : 'true');
            });
        }

        showItem(0);

        setInterval(function () {
            showItem((index + 1) % items.length);
        }, interval);
    });
})();
</script>
