<?php defined('_JEXEC') or die; if(!$list)return; ?>
<div class="roja-breaking-row"><span class="roja-breaking-label">BREAKING</span><div class="roja-breaking-items">
<?php foreach($list as $item): ?><a href="<?php echo $item->link; ?>"><?php echo htmlspecialchars($item->title,ENT_QUOTES,'UTF-8'); ?></a><?php endforeach; ?>
</div></div>
