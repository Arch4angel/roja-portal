<?php
defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;

if (!$list) {
    return;
}
?>
<?php if (!empty($module->title) && $module->showtitle) : ?>
    <h2 class="roja-module-title"><?php echo htmlspecialchars($module->title, ENT_QUOTES, 'UTF-8'); ?></h2>
<?php endif; ?>
<div class="roja-grid">
    <?php foreach ($list as $item) : ?>
        <?php $images = json_decode((string) ($item->images ?? '{}'), true); $src = $images['image_intro'] ?? $images['image_fulltext'] ?? ''; ?>
        <article class="roja-card">
            <div style="aspect-ratio:16/10; overflow:hidden;">
                <?php if ($src) : ?>
                    <img src="<?php echo htmlspecialchars($src, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($item->title, ENT_QUOTES, 'UTF-8'); ?>" loading="lazy" decoding="async">
                <?php else : ?>
                    <div class="roja-placeholder"></div>
                <?php endif; ?>
            </div>
            <div class="roja-card-body">
                <?php if ($params->get('show_category', 1) && !empty($item->category_title)) : ?>
                    <div class="roja-kicker"><?php echo htmlspecialchars($item->category_title, ENT_QUOTES, 'UTF-8'); ?></div>
                <?php endif; ?>
                <h3 class="roja-card-title"><a href="<?php echo $item->link; ?>"><?php echo htmlspecialchars($item->title, ENT_QUOTES, 'UTF-8'); ?></a></h3>
                <?php if ($params->get('show_date', 1)) : ?>
                    <div class="roja-meta"><?php echo HTMLHelper::_('date', $item->publish_up, 'd M Y'); ?></div>
                <?php endif; ?>
            </div>
        </article>
    <?php endforeach; ?>
</div>
