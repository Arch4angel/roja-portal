<?php defined('_JEXEC') or die; if(!$list)return; ?>
<?php if(!empty($module->title) && $module->showtitle): ?><h2 class="roja-module-title"><?php echo htmlspecialchars($module->title,ENT_QUOTES,'UTF-8'); ?></h2><?php endif; ?>
<div class="roja-trending-list"><?php foreach($list as $i=>$item): ?><div class="roja-trending-item"><span class="roja-rank"><?php echo str_pad((string)($i+1),2,'0',STR_PAD_LEFT); ?></span><a href="<?php echo $item->link; ?>"><?php echo htmlspecialchars($item->title,ENT_QUOTES,'UTF-8'); ?></a></div><?php endforeach; ?></div>
