<?php
namespace Roja\Module\Trending\Site\Helper;
defined('_JEXEC') or die;
use Joomla\CMS\Access\Access;
use Joomla\CMS\Application\SiteApplication;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Router\Route;
use Joomla\Component\Content\Site\Helper\RouteHelper;
use Joomla\Registry\Registry;
class ArticlesHelper {
 public function getArticles(Registry $params, SiteApplication $app): array {
   $model=$app->bootComponent('com_content')->getMVCFactory()->createModel('Articles','Site',['ignore_request'=>true]);
   $model->setState('params',$app->getParams()); $model->setState('list.start',0); $model->setState('filter.published',1); $model->setState('filter.condition',1); $model->setState('filter.language',$app->getLanguageFilter()); $model->setState('filter.access',!ComponentHelper::getParams('com_content')->get('show_noauth')); $model->setState('list.limit',(int)$params->get('count',5)); $model->setState('load_tags',false);
   $cats=(array)$params->get('catid',[]); if($cats){$model->setState('filter.category_id',$cats);} 
   $featured=(string)$params->get('featured','trending'==='hero'?'1':''); if($featured==='1'){$model->setState('filter.featured','only');} elseif($featured==='0'){$model->setState('filter.featured','hide');} else {$model->setState('filter.featured','show');}
   $ordering=(string)$params->get('ordering','trending'==='trending'?'hits':'publish_up');
   $allowed=['publish_up'=>'a.publish_up','created'=>'a.created','modified'=>'a.modified','hits'=>'a.hits']; $model->setState('list.ordering',$allowed[$ordering]??'a.publish_up'); $model->setState('list.direction','DESC');
   $items=(array)$model->getItems(); $levels=Access::getAuthorisedViewLevels($app->getIdentity()->id); $access=!ComponentHelper::getParams('com_content')->get('show_noauth');
   foreach($items as &$item){$item->slug=$item->id.':'.$item->alias; $item->link=($access||in_array($item->access,$levels))?Route::_(RouteHelper::getArticleRoute($item->slug,$item->catid,$item->language)):Route::_('index.php?option=com_users&view=login');}
   return $items;
 }
}
