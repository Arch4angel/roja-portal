<?php
namespace Roja\Module\Trending\Site\Helper;

defined('_JEXEC') or die;

use Joomla\CMS\Access\Access;
use Joomla\CMS\Application\SiteApplication;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Router\Route;
use Joomla\Component\Content\Site\Helper\RouteHelper;
use Joomla\Registry\Registry;

class ArticlesHelper
{
    public function getArticles(Registry $params, SiteApplication $app): array
    {
        $contentParams = ComponentHelper::getParams('com_content');
        $model = $app->bootComponent('com_content')
            ->getMVCFactory()
            ->createModel('Articles', 'Site', ['ignore_request' => true]);

        $model->setState('params', $app->getParams());
        $model->setState('list.start', 0);
        $model->setState('list.limit', max(1, (int) $params->get('count', 5)));
        $model->setState('filter.published', 1);
        $model->setState('filter.condition', 1);
        $model->setState('filter.language', $app->getLanguageFilter());
        $model->setState('filter.access', !(bool) $contentParams->get('show_noauth', false));
        $model->setState('load_tags', false);

        $categories = array_values(array_filter(array_map('intval', (array) $params->get('catid', []))));
        if ($categories !== []) {
            $model->setState('filter.category_id', $categories);
        }

        $featured = (string) $params->get('featured', '');
        if ($featured === '1') {
            $model->setState('filter.featured', 'only');
        } elseif ($featured === '0') {
            $model->setState('filter.featured', 'hide');
        } else {
            $model->setState('filter.featured', 'show');
        }

        $ordering = (string) $params->get('ordering', 'hits');
        $allowedOrdering = [
            'publish_up' => 'a.publish_up',
            'created' => 'a.created',
            'modified' => 'a.modified',
            'hits' => 'a.hits',
        ];

        $model->setState('list.ordering', $allowedOrdering[$ordering] ?? 'a.publish_up');
        $model->setState('list.direction', 'DESC');

        $items = (array) $model->getItems();
        $identity = $app->getIdentity();
        $levels = $identity ? Access::getAuthorisedViewLevels((int) $identity->id) : [1];
        $showNoAuth = (bool) $contentParams->get('show_noauth', false);

        foreach ($items as $index => $item) {
            if (!isset($item->id)) {
                unset($items[$index]);
                continue;
            }

            $item->slug = (int) $item->id . ':' . ($item->alias ?? '');
            $item->link = ($showNoAuth || in_array((int) ($item->access ?? 0), $levels, true))
                ? RouteHelper::getArticleRoute($item->slug, (int) ($item->catid ?? 0), $item->language ?? '*')
                : Route::_('index.php?option=com_users&view=login');
        }

        return array_values($items);
    }
}
