<?php
namespace Roja\Module\Trending\Site\Dispatcher;
defined('_JEXEC') or die;
use Joomla\CMS\Dispatcher\AbstractModuleDispatcher;
use Joomla\CMS\Helper\HelperFactoryAwareInterface;
use Joomla\CMS\Helper\HelperFactoryAwareTrait;
class Dispatcher extends AbstractModuleDispatcher implements HelperFactoryAwareInterface { use HelperFactoryAwareTrait; protected function getLayoutData(){ $data=parent::getLayoutData(); $data['list']=$this->getHelperFactory()->getHelper('ArticlesHelper')->getArticles($data['params'],$this->getApplication()); return $data; } }
